# LampsPRO CRM

A polished static prototype for a consulting-company CRM.

## Included
- Executive dashboard
- Client management
- Opportunity pipeline
- Consulting projects
- Proposals
- Tasks
- Calendar
- Team utilization
- Reports
- Settings
- Working create forms and demo interactions
- Responsive mobile layout

## Run locally
Open `index.html` in a browser.

## GitHub Pages
Upload `index.html` to a repository and enable GitHub Pages. For a project repository, the published address follows:
`https://YOUR-USERNAME.github.io/REPOSITORY/`

This is a front-end prototype. Authentication, a real database, multi-tenant security, file storage, email, payments and server-side persistence should be connected before production use.
